function creationbague(){
	var baguejaune = document.getElementById("baguejaune").checked;
	var pierrejaune = document.getElementById("pierrejaune").checked;
	var baguerose = document.getElementById("baguerose").checked;
	var pierrerose = document.getElementById("pierrerose").checked;
	var bagueblanc = document.getElementById("bagueblanc").checked;
	var pierreblanc = document.getElementById("pierreblanc").checked;*/

	if (document.getElementById('baguejaune').checked) {
		document.getElementById('pierrejaune').style.visibility=visible;
	}

	if (baguejaune ==true) {

	}

}
